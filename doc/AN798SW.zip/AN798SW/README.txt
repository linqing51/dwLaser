EEPROM EMULATION

* It implement wear leveling method to emulate less than 254 bytes size eeprom.
* In default It takes two pages to emulate eeprom. User can add more pages base on their requrement.

